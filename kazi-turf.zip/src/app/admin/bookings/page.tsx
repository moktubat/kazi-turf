import type { Metadata } from "next";
import { BookingsView } from "@/components/pages/admin/BookingsView";
import { addDays } from "@/lib/time";
import { accessibleBranches } from "@/server/admin/access";
import { requireStaffPage } from "@/server/auth/pageGuards";
import { todayDhaka } from "@/lib/time.server";

export const metadata: Metadata = { title: "Bookings" };

type Params = Promise<Record<string, string | string[] | undefined>>;

export default async function AdminBookingsPage({ searchParams }: { searchParams: Params }) {
    const sp = await searchParams;
    const user = await requireStaffPage("/admin/bookings");
    const mine = accessibleBranches(user);
    const venue = mine[0];

    const today = await todayDhaka();

    const requestParam = Array.isArray(sp.request) ? sp.request[0] : sp.request;
    const requestOnly = requestParam === "open";

    return (
        <div className="mx-auto max-w-main space-y-5 px-4 py-5 pb-24">
            <h1 className="text-2xl font-extrabold md:text-3xl">Bookings</h1>
            <BookingsView
                role={user.role}
                defaults={{
                    from: requestOnly ? addDays(today, -90) : addDays(today, -7),
                    to: addDays(today, 30),
                    requestOnly,
                }}
            />
        </div>
    );
}