import { pricingRules } from "@/data/pricing";
import { todayDhaka } from "@/lib/time.server";

const DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function dayLabel(days: number[]): string {
    const d = [...days].sort((a, b) => a - b);
    if (d.length === 1) return DAY[d[0]];
    const contiguous = d.every((v, i) => i === 0 || v === d[i - 1] + 1);
    return contiguous ? `${DAY[d[0]]}–${DAY[d[d.length - 1]]}` : d.map((x) => DAY[x]).join(", ");
}

export interface RateCell {
    price: number;
    window: string;
}

export interface RateRow {
    days: string;
    offPeak: RateCell | null;
    peak: RateCell | null;
}

export async function getRateTable(pitchId: string): Promise<RateRow[]> {
    const today = await todayDhaka();

    const rows = new Map<string, RateRow>();

    for (const r of pricingRules.filter(
        (x) =>
            x.pitchId === pitchId &&
            (!x.effectiveFrom || today >= x.effectiveFrom) &&
            (!x.effectiveTo || today <= x.effectiveTo)
    )) {
        const key = [...r.days].sort((a, b) => a - b).join(",");
        const row = rows.get(key) ?? {
            days: dayLabel(r.days),
            offPeak: null,
            peak: null,
        };

        const cell = {
            price: r.pricePerSlot,
            window: `${r.startTime}–${r.endTime}`,
        };

        if (r.tier === "Peak") row.peak = cell;
        else row.offPeak = cell;

        rows.set(key, row);
    }

    return [...rows.values()];
}